document

document.getElementById("nav-bar")

document.getElementById("nav-bar").innerHTML

document.getElementById("nav-bar").innerHTML = "<h1> That was supposed to be the nav bar </h1>"

document.getElementsByClassName("row")

var rowDivs = document.getElementsByClassName("row")

rowDivs[0]

document.getElementsByTagName("a")

document.querySelector("#nav-bar")

document.querySelectorAll(".row")

document.querySelector(".row a")

document.querySelector(".row a").getAttribute("class")

document.querySelector(".row a").className

document.querySelector(".row a").classList

document.querySelector(".row a").setAttribute("href","https://www.google.com")

